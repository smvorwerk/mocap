Version: 0.0.1
**Make sure you are running the latest version to prevent error.**

Browse to your project folder.
Copy Plugins folder into your Project root.
Check out https://mocap.robotrebellion.xyz/ for more information.
